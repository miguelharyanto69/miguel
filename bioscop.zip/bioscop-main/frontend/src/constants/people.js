import profile from "../assets/image/profile.jpg";

const peoples = [
    {
        name:'Maria Hill',
        message:'Hey how are you today?',
        profile
    },
    {
        name:'Jane',
        message:'Sounds good , let`s do this',
        profile 
    },
    {
        name:'Jane',
        message:'Sounds good , let`s do this',
        profile 
    },
    {
        name:'Jane',
        message:'Sounds good , let`s do this',
        profile 
    },
    {
        name:'Jane',
        message:'Sounds good , let`s do this',
        profile 
    },
]

export default peoples;